###############################################################################
#
#	READ_ME.txt
#
#	Author: Dr. Aidan Wimshurst (FluidMechanics101)
#
#	- Email: FluidMechanics101@gmail.com
#	- Web  : https://www.fluidmechanics101.com
#	- YouTube: Fluid Mechanics 101
#
#	Version 1.0.0 22/06/2019
#
###############################################################################

Welcome to my Computational Fluid Dynamics Fundamentals Course! I put together this course to help you develop a deep understanding of Computational Fluid Dynamics (CFD), so that you can set up, run and post-process engineering simulations of fluids (liquids and gases) more effectively. This course starts from the absolute basics, with the only prior knowledge required being basic calculus, differential equations and vector operations. These basics are typically taught during first year college/university courses and in some cases secondary/high school lessons. Hence, this course is perfect for anyone with a foundational background in science/mathematics/engineering or physics. 

To start the course, open up the PDF and follow along with the slides. At times, you will be instructed to open up the excel spreadsheets or python source code. Either of these can be used to follow the examples. So choose whichever you feel more comfortable with. No additional coding or scripting is required as the examples are complete and ready to go. Of course, feel free to manipuate the code and even write your own if you feel like. All of this should help to improve your understanding and get more out of the course, so proceed as you like! 

Once you have finished the course, if there was anything you particularly liked/disliked or if you have any ideas about how the course could be made even better for others, please drop me an email or leave a comment on any of my YouTube videos. I really appreciate your feedback and would like to make the best possible content for you in future. 

All the best
Aidan